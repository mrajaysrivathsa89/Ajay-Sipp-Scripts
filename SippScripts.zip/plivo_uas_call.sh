#!/bin/bash

RemoteServer=phone.plivo.com
ScenarioFile=plivo_uas_call.xml
InjectionFile=plivo_uas_call.csv
SourceIP=192.168.0.100
SourcePort=5066

sudo ./sipp $RemoteServer -sf $ScenarioFile -inf $InjectionFile -r 1 -m 1 -i $SourceIP -p $SourcePort -trace_msg -trace_err


