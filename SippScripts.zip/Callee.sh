sh plivo_uas_reg.sh
echo "Registration Done."

sleep 3

sh plivo_uas_call.sh
echo "Waiting For Call."

