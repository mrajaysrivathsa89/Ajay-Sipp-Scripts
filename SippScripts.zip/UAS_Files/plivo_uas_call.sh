#!/bin/bash

RemoteServer=phone.plivo.com
ScenarioFile=plivo_uas_call.xml
InjectionFile=plivo_uas_call.csv
SourceIP=10.211.63.75
SourcePort=5066

./sipp $RemoteServer -sf $ScenarioFile -inf $InjectionFile -r 1 -m 1 -i $SourceIP -p $SourcePort  -aa -trace_msg -trace_err


