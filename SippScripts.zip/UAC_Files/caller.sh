sh plivo_uac_reg.sh
echo "Registration Done."

sleep 3

sh plivo_uac_call.sh
echo "Call initiated."

