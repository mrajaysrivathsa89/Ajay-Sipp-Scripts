#!/bin/bash

RemoteServer=phone.plivo.com
ScenarioFile=plivo_uac_call.xml
InjectionFile=plivo_uac_call.csv
SourceIP=192.168.0.104
SourcePort=5065
Service=peter2828846065214485912

sudo ./sipp $RemoteServer -sf $ScenarioFile -inf $InjectionFile -r 1 -m 1 -i $SourceIP -p $SourcePort -s $Service -trace_msg -trace_err


