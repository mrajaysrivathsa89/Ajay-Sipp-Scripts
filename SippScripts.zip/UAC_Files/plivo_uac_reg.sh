#!/bin/bash

RemoteServer=phone.plivo.com
ScenarioFile=REGISTER.xml
InjectionFile=plivo_uac_reg.csv
SourceIP=192.168.0.104
SourcePort=5065
Service=harry16207269196093298542

sudo ./sipp $RemoteServer -sf $ScenarioFile -inf $InjectionFile -r 1 -m 1 -i $SourceIP -p $SourcePort -trace_msg -trace_err


