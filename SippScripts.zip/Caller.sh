sh plivo_uac_reg.sh
echo "Registration Done."

sleep 3

echo "Call initiated."
sh plivo_uac_call.sh
