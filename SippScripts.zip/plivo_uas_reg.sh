#!/bin/bash

RemoteServer=phone.plivo.com
ScenarioFile=plivo_ua_reg.xml
InjectionFile=plivo_uas_reg.csv
SourceIP=192.168.0.100
SourcePort=5066

sudo ./sipp $RemoteServer -sf $ScenarioFile -inf $InjectionFile -r 1 -m 1 -i $SourceIP -p $SourcePort -trace_msg -trace_err


